# Contributing to KibTool

All contributions are welcome: ideas, patches, documentation, bug reports,
complaints, etc!

## Have an Idea or Feature Request?

* File a ticket on [github](https://github.com/pchanas/KibanaRatioCalculation/issues)
* Feel free to contribute [github](https://github.com/pchanas/KibanaRatioCalculation/pulls)

## Something Not Working? Found a Bug?

If you think you found a bug, it probably is a bug.

* File it on [github](https://github.com/pchanas/KibanaRatioCalculation/issues)
